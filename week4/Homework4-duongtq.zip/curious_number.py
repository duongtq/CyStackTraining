#factorial function for calculating factorial

def factorial(number):
	i = 1
	result = 1
	while i <= number:
		result = result * i
		i += 1
	return result

#time module for calculating time of execution
import time

#time at the start of program execution
start = time.time()

#factorials of numbers from 0-9
f = [
factorial(0),
factorial(1),
factorial(2),
factorial(3),
factorial(4),
factorial(5),
factorial(6),
factorial(7),
factorial(8),
factorial(9)]

#sum of factorial of the digits
def factorial_digits(n):
	factorial_sum = 0
	while n:
		factorial_sum += f[n%10]
		n = n // 10
	return factorial_sum

#variable to save the value of solution

solution = 0
for i in xrange(0,10000000):
	if factorial_digits(i) == i:
		solution += i

#printing the solution
print "Sum: ", solution

#Time at the end of program execution
end = time.time()
ex_time = end - start

#total time of execution
print "Execution time: ", ex_time