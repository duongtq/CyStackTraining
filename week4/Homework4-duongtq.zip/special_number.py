# Create a function to find the number which is the sum of square of 5 of each digit

def find_suitable_number(number):
	str_number = str(number)
	i = 0
	result = 0
	size = len(str_number)
	for i in range(size):
		temp = int(str_number[i])
		result += temp**5

		if result == number:
			return number

	return -1

# Test the function 
j = 0
sum = 0
for j in range(1000000):
	if find_suitable_number(j) == j:
		print(j)
		sum += j

print "Sum of all special numbers: ", sum