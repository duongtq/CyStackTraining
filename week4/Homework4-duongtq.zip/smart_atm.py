target = 1000000
coins = [1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 500000]
ways = [1] + [0]*target

for coin in coins:
    for i in range(coin, target+1):
        ways[i] += ways[i-coin]

print "Number of ways to get 1000000VND from smaller units: ", ways[target]

