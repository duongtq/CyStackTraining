import zipfile

zip_file = zipfile.ZipFile('encrypted.zip')
pass_file = open('cain.txt')

for line in pass_file.readlines():
	password = line.strip('\n')
	try:
		zip_file.extractall(pwd=password)
		print "Password: " + password + '\n'
		print zip_file.read("flag.txt", pwd=password)

		exit(0)
	except Exception, e:
		pass
